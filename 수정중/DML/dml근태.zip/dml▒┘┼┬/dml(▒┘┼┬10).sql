-- dml - Attendance10~12.sql
-- depth4
-- 작성자: 김민도

-- registeredCourseSeq 1, Java 과정
-- 2027-01-04 시작예정 ~
-- 1강의실 18/30명

-- registeredCourseSeq 6, Python 과정
-- 2027-03-02 시작예정 ~
-- 2강의실 25/30명

-- registeredCourseSeq 7, AI 과정
-- 2027-05-03 시작예정 ~
-- 3강의실 25/30명

-- 3개의 강의는 기준일보다 늦게 시작하는 강의로 수강대기중 상태임으로 자료없음